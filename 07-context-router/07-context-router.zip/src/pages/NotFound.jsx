import React from "react";

const NotFound = () => {
  return <h1 className="text-center mt-3 text-danger">404 Not Found Page</h1>;
};

export default NotFound;
