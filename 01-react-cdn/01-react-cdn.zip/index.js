ReactDOM.render(<Contador />, document.querySelector("#root"));
