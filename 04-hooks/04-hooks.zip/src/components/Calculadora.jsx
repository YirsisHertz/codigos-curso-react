import NumberInput from "./NumberInput";

const Calculadora = () => {
  return (
    <div>
      <NumberInput />
    </div>
  );
};

export default Calculadora;
