import Cards from "./components/Cards";

const App = () => {
  return <Cards />;
};

export default App;
