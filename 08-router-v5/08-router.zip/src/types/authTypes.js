export const authTypes = {
  login: "login",
  logout: "logout",
};
